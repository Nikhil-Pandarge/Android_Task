package com.example.filehandling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
EditText ed1;
TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
        t1=findViewById(R.id.textView);

    }
    public void Write(View view)
    {
        String name=ed1.getText().toString();
        try
        {
            OutputStreamWriter osw=new OutputStreamWriter(openFileOutput("collage.txt",MODE_PRIVATE));
            osw.write(name);
            osw.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Read(View view)
    {
        try
        {
            InputStreamReader isr=new InputStreamReader(openFileInput("collage.txt"));
            BufferedReader br=new BufferedReader(isr);
            String name=br.readLine();
            t1.setText(name);
            Toast.makeText(getApplicationContext(),getFilesDir().getAbsolutePath(),Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
